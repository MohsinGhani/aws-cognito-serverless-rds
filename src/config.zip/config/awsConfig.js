const awsConfig = {
    // REQUIRED - Amazon Cognito Identity Pool ID
    identityPoolId: 'us-east-2:a7722a42-2437-43f2-9797-4368d197c008',
    // REQUIRED - Amazon Cognito Region
    region: 'us-east-2',
    // OPTIONAL - Amazon Cognito User Pool ID
    userPoolId: 'us-east-2_559K3rNJ7',
    // OPTIONAL - Amazon Cognito Web Client ID
    userPoolWebClientId: '3l3gbrnrolgd8vtg0vktvtfi8u',
}

export default awsConfig 
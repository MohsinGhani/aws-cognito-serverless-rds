const credentials = {
    GOOGLE_CLIENT_ID: '1088278371830-65jkg4ilfos10o224iqjar72dfu9h52m.apps.googleusercontent.com',
    FB_APP_ID: '1191719771010400',
    BASE_URL : 'https://o0pjjcwlk5.execute-api.us-east-1.amazonaws.com/dev',
    MAP_ACCESS_TOCKEN: 'pk.eyJ1IjoibW9oc2luZ2hhbmkiLCJhIjoiY2pzYjYwZzV1MDZuajQ5cGVlOTF2dWM5YSJ9.0d-GKJT3DxmM7itEfPN1MA'
}

export default credentials